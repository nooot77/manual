<?php
return [
    'inputContainer' => '<div class="custom-container form-group{{required}}">{{content}}{{help}}</div>'
];
