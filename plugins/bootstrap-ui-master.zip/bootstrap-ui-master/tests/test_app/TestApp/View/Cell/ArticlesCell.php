<?php
namespace TestApp\View\Cell;

use Cake\View\Cell;

class ArticlesCell extends Cell
{

    /**
     * Default cell action.
     *
     * @return void
     */
    public function display()
    {
    }
}
