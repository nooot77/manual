<?php
namespace Nested\TestPluginTwo\Controller;

use Cake\Controller\Controller;

class PluginTwoController extends Controller
{

    public function index()
    {
    }

    public function add()
    {
    }

    public function edit()
    {
    }
}
