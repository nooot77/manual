<?php
namespace Acl\Controller\Admin;

use Cake\Controller\Controller;

class PostsController extends Controller
{

    public function index()
    {
    }

    public function add()
    {
    }

    public function edit()
    {
    }
}

class BigLongNamesController extends Controller
{

    public function index()
    {
    }

    public function view()
    {
    }

    public function add()
    {
    }

    public function delete()
    {
    }
}
