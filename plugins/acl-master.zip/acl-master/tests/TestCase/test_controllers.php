<?php
namespace Acl\Controller;

use Cake\Controller\Controller;

class CommentsController extends Controller
{

    public function add()
    {
    }

    public function index()
    {
    }

    public function delete()
    {
    }

    protected function _secret_method()
    {
    }
}

class PostsController extends Controller
{

    public function index()
    {
    }

    public function add()
    {
    }

    public function edit()
    {
    }
}

class BigLongNamesController extends Controller
{

    public function index()
    {
    }

    public function view()
    {
    }

    public function add()
    {
    }

    public function delete()
    {
    }
}

abstract class AbstractController extends Controller
{

    public function index()
    {
    }

    public function view()
    {
    }

    public function add()
    {
    }

    public function delete()
    {
    }
}

class ConcreteController extends AbstractController
{

    public function index()
    {
    }

    public function view()
    {
    }

    public function add()
    {
    }

    public function delete()
    {
    }
}
