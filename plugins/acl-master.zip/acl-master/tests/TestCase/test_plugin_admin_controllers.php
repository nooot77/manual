<?php
namespace TestPlugin\Controller\Admin;

use Cake\Controller\Controller;

class PluginController extends Controller
{

    public function index()
    {
    }

    public function add()
    {
    }

    public function edit()
    {
    }
}
