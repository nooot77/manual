<?php

namespace TestApp\Controller\Admin\V10\Authors\Editors;

class DummyController
{

    public function implementedEvents()
    {
        return [];
    }

    public function doSomething()
    {
    }

    public function doSomethingElse()
    {
    }
}
