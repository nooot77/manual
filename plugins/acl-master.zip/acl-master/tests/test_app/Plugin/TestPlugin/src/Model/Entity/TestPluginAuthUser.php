<?php

namespace TestPlugin\Model\Entity;

use Cake\ORM\Entity;

class TestPluginAuthUser extends Entity
{
}
