<?php
use Cake\Routing\Router;

Router::plugin('AkkaCKEditor', function ($routes) {
    $routes->fallbacks();
});
